# ineedanexpert.org
Connecting experts with people in need of teaching.
Bringing people together.
Maximising synergy in the workplace.